"""
reconcile.py
------------
Main orchestrator for the Guidewire ODS Reconciliation Framework.

Usage (Databricks notebook or job):

    from config import ReconciliationConfig
    from reconcile import run_reconciliation

    cfg = ReconciliationConfig(lookback_days=14)
    summary_df = run_reconciliation(spark, cfg)
    display(summary_df)

Design goals covered here:
  - Modular: discovery / schema_compare / data_compare are independent,
    testable units; this file only wires them together.
  - Scalable: table list is discovered from the catalog, not hard-coded,
    so it works for 3 tables or 500.
  - Fault tolerant: each table is processed in isolation; a failure on
    one table is logged and recorded as an ERROR row, the run continues.
  - Observable: structured logs + a RunMetrics summary + a persisted
    Delta table of per-table results with full history (run_id, run_ts).
"""
import time
from typing import List

from pyspark.sql import DataFrame
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, DoubleType, BooleanType, TimestampType
)

from config import ReconciliationConfig
from discovery import discover_table_pairs, find_cda_only_tables, TablePair
from schema_compare import compare_schema
from data_compare import compare_data
from logging_utils import get_logger, RunMetrics, timed

logger = get_logger()

RESULT_SCHEMA = StructType([
    StructField("run_id", StringType()),
    StructField("run_timestamp", TimestampType()),
    StructField("domain", StringType()),
    StructField("source_table", StringType()),
    StructField("target_table", StringType()),
    StructField("table_status", StringType()),          # OK | MISSING_IN_TARGET | ERROR
    StructField("schema_status", StringType()),          # SCHEMA_MATCH | SCHEMA_DRIFT | SCHEMA_MISMATCH | N/A
    StructField("data_status", StringType()),             # DATA_MATCH | DATA_MISMATCH | NOT_COMPARED
    StructField("overall_status", StringType()),          # PASS | FAIL | WARN | ERROR
    StructField("source_row_count", LongType()),
    StructField("target_row_count", LongType()),
    StructField("comparison_mode", StringType()),         # FULL | SAMPLE | SKIPPED | NONE
    StructField("filter_applied", BooleanType()),
    StructField("filter_column", StringType()),
    StructField("rows_only_in_source", LongType()),
    StructField("rows_only_in_target", LongType()),
    StructField("sample_size", LongType()),
    StructField("sample_match_rate", DoubleType()),
    StructField("columns_only_in_source", StringType()),
    StructField("columns_only_in_target", StringType()),
    StructField("datatype_mismatches", StringType()),
    StructField("nullability_mismatches", StringType()),
    StructField("duration_seconds", DoubleType()),
    StructField("comments", StringType()),
])


def _fmt_list(items) -> str:
    return ", ".join(str(i) for i in items) if items else ""


def _fmt_type_mismatches(items) -> str:
    return "; ".join(f"{c}: source={s} vs target={t}" for c, s, t in items) if items else ""


def _fmt_null_mismatches(items) -> str:
    return "; ".join(f"{c}: source_nullable={s} vs target_nullable={t}" for c, s, t in items) if items else ""


def _build_comments(schema_result, data_result, table_status: str) -> str:
    parts = []
    if table_status == "MISSING_IN_TARGET":
        return "Table exists in Read Replica but was not found in CDA."
    if schema_result:
        if schema_result.columns_only_in_source:
            parts.append(f"{len(schema_result.columns_only_in_source)} column(s) missing in CDA "
                         f"(present in Read Replica baseline): {_fmt_list(schema_result.columns_only_in_source)}.")
        if schema_result.columns_only_in_target:
            parts.append(f"{len(schema_result.columns_only_in_target)} extra column(s) in CDA "
                         f"(schema drift, allowed): {_fmt_list(schema_result.columns_only_in_target)}.")
        if schema_result.datatype_mismatches:
            parts.append(f"Datatype mismatch on {len(schema_result.datatype_mismatches)} column(s): "
                         f"{_fmt_type_mismatches(schema_result.datatype_mismatches)}.")
        if schema_result.nullability_mismatches:
            parts.append(f"Nullability differs on {len(schema_result.nullability_mismatches)} column(s): "
                         f"{_fmt_null_mismatches(schema_result.nullability_mismatches)}.")
        if schema_result.ignored_columns:
            parts.append(f"Excluded from data comparison by design (audit/CDC columns): "
                         f"{_fmt_list(schema_result.ignored_columns)}.")
    if data_result:
        if data_result.comparison_mode == "SKIPPED":
            parts.append("No comparable common columns after exclusions -- data comparison skipped.")
        elif data_result.source_row_count != data_result.target_row_count:
            parts.append(f"Row count mismatch (expected in this env): source={data_result.source_row_count}, "
                         f"target={data_result.target_row_count}.")
        if data_result.comparison_mode == "FULL":
            if data_result.rows_only_in_source or data_result.rows_only_in_target:
                parts.append(f"Full compare: {data_result.rows_only_in_source} row(s) only in Read Replica, "
                             f"{data_result.rows_only_in_target} row(s) only in CDA.")
            else:
                parts.append("Full compare: all rows match on common columns.")
        elif data_result.comparison_mode == "SAMPLE":
            if data_result.sample_match_rate is not None:
                parts.append(f"Sample compare ({data_result.sample_size} rows): "
                             f"{data_result.sample_match_rate * 100:.2f}% match rate against CDA.")
            else:
                parts.append("Sample compare produced no rows to evaluate.")
        if data_result.filter_applied:
            parts.append(f"Incremental filter applied on {data_result.filter_column.upper()} "
                         f"window {data_result.filter_window}.")
        else:
            parts.append("No UPDATETIME/CREATETIME column found -- full table compared, no date filter.")
    return " ".join(parts) if parts else "No issues detected."


def _overall_status(table_status: str, schema_status: str, data_status: str) -> str:
    if table_status in ("MISSING_IN_TARGET", "ERROR"):
        return "FAIL" if table_status == "MISSING_IN_TARGET" else "ERROR"
    if schema_status == "SCHEMA_MISMATCH" or data_status == "DATA_MISMATCH":
        return "FAIL"
    if schema_status == "SCHEMA_DRIFT":
        return "WARN"
    if data_status == "NOT_COMPARED":
        return "WARN"
    return "PASS"


def _reconcile_one(spark, pair: TablePair, config: ReconciliationConfig, run_id: str, run_ts) -> dict:
    start = time.time()
    base = dict(
        run_id=run_id, run_timestamp=run_ts, domain=pair.domain,
        source_table=pair.source_table, target_table=pair.target_table,
    )

    if not pair.exists_in_target:
        base.update(
            table_status="MISSING_IN_TARGET", schema_status="N/A", data_status="NOT_COMPARED",
            overall_status="FAIL", source_row_count=None, target_row_count=None,
            comparison_mode="SKIPPED", filter_applied=False, filter_column=None,
            rows_only_in_source=None, rows_only_in_target=None, sample_size=None,
            sample_match_rate=None, columns_only_in_source=None, columns_only_in_target=None,
            datatype_mismatches=None, nullability_mismatches=None,
            duration_seconds=round(time.time() - start, 2),
            comments=_build_comments(None, None, "MISSING_IN_TARGET"),
        )
        return base

    schema_result = compare_schema(spark, pair, config)
    data_result = compare_data(spark, pair, schema_result, config)

    schema_status = schema_result.status()
    data_status = data_result.status()
    overall = _overall_status("OK", schema_status, data_status)

    base.update(
        table_status="OK",
        schema_status=schema_status,
        data_status=data_status,
        overall_status=overall,
        source_row_count=data_result.source_row_count,
        target_row_count=data_result.target_row_count,
        comparison_mode=data_result.comparison_mode,
        filter_applied=data_result.filter_applied,
        filter_column=data_result.filter_column,
        rows_only_in_source=data_result.rows_only_in_source,
        rows_only_in_target=data_result.rows_only_in_target,
        sample_size=data_result.sample_size,
        sample_match_rate=data_result.sample_match_rate,
        columns_only_in_source=_fmt_list(schema_result.columns_only_in_source),
        columns_only_in_target=_fmt_list(schema_result.columns_only_in_target),
        datatype_mismatches=_fmt_type_mismatches(schema_result.datatype_mismatches),
        nullability_mismatches=_fmt_null_mismatches(schema_result.nullability_mismatches),
        duration_seconds=round(time.time() - start, 2),
        comments=_build_comments(schema_result, data_result, "OK"),
    )
    return base


def run_reconciliation(spark, config: ReconciliationConfig) -> DataFrame:
    import uuid
    from datetime import datetime

    run_id = str(uuid.uuid4())
    run_ts = datetime.utcnow()
    metrics = RunMetrics()
    metrics.run_id = run_id

    logger.info(f"Starting reconciliation run {run_id}")
    logger.info(f"Source: {config.source_schema_fqn()} | Target: {config.target_schema_fqn()}")

    pairs = discover_table_pairs(spark, config)
    logger.info(f"Discovered {len(pairs)} Read Replica table(s) across domains: {list(config.domains)}")

    cda_only = find_cda_only_tables(spark, config)
    if cda_only:
        logger.warning(f"{len(cda_only)} table(s) exist only in CDA (no Read Replica source): {cda_only}")

    results: List[dict] = []
    for pair in pairs:
        table_label = f"{pair.domain}.{pair.source_table}"
        attempts = 0
        while True:
            attempts += 1
            try:
                with timed(metrics, table_label):
                    row = _reconcile_one(spark, pair, config, run_id, run_ts)
                metrics.record_status(table_label, row["overall_status"])
                logger.info(f"[{row['overall_status']}] {table_label} "
                            f"(schema={row['schema_status']}, data={row['data_status']}, "
                            f"src_rows={row['source_row_count']}, tgt_rows={row['target_row_count']})")
                results.append(row)
                break
            except Exception as e:
                if attempts <= config.max_table_retries:
                    logger.warning(f"Retrying {table_label} after error: {e!r}")
                    continue
                logger.error(f"[ERROR] {table_label} failed after {attempts} attempt(s): {e!r}")
                metrics.record_error(table_label, e)
                metrics.record_status(table_label, "ERROR")
                results.append(dict(
                    run_id=run_id, run_timestamp=run_ts, domain=pair.domain,
                    source_table=pair.source_table, target_table=pair.target_table,
                    table_status="ERROR", schema_status="N/A", data_status="NOT_COMPARED",
                    overall_status="ERROR", source_row_count=None, target_row_count=None,
                    comparison_mode="NONE", filter_applied=False, filter_column=None,
                    rows_only_in_source=None, rows_only_in_target=None, sample_size=None,
                    sample_match_rate=None, columns_only_in_source=None, columns_only_in_target=None,
                    datatype_mismatches=None, nullability_mismatches=None,
                    duration_seconds=None, comments=f"Reconciliation failed: {e!r}",
                ))
                if not config.continue_on_error:
                    raise
                break

    metrics.finalize()
    metrics.print_summary(logger)

    if config.fail_run_if_error_rate_above is not None:
        if metrics.error_rate() > config.fail_run_if_error_rate_above:
            raise RuntimeError(
                f"Reconciliation error rate {metrics.error_rate():.1%} exceeded threshold "
                f"{config.fail_run_if_error_rate_above:.1%}"
            )

    summary_df = spark.createDataFrame(results, schema=RESULT_SCHEMA)

    if config.write_results_to_delta:
        target = config.output_table_fqn()
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {config.output_catalog}.{config.output_schema}")
            (summary_df.write.format("delta")
                .mode(config.results_mode)
                .option("mergeSchema", "true")
                .saveAsTable(target))
            logger.info(f"Reconciliation results written to {target} ({config.results_mode} mode)")
        except Exception as e:
            logger.error(f"Failed to persist results to {target}: {e!r}")

    return summary_df
