"""
data_compare.py
----------------
Row-level data comparison between a Read Replica table and its CDA
counterpart, restricted to the columns common to both schemas (minus
audit/CDC columns). Handles three table shapes:

  1. Has UPDATETIME            -> filter both sides on the configured
                                   date window using UPDATETIME.
  2. Has CREATETIME only       -> filter both sides using CREATETIME.
  3. Has neither                -> full table, no filter.

Because Read Replica refreshes daily and CDA loads on demand, row counts
routinely diverge in this environment. Strategy:

  - counts match      -> full set-based comparison (hash-diff) on the
                          filtered/complete data.
  - counts mismatch    -> representative random sample from the smaller
                          side, checked for presence/equality against the
                          other side, so data-quality issues still surface
                          instead of being skipped.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, functions as F

from config import ReconciliationConfig
from schema_compare import SchemaComparisonResult


@dataclass
class DataComparisonResult:
    source_row_count: int = 0
    target_row_count: int = 0
    comparison_mode: str = "NONE"          # FULL | SAMPLE | SKIPPED
    filter_applied: bool = False
    filter_column: Optional[str] = None
    filter_window: Optional[Tuple[str, str]] = None
    rows_only_in_source: int = 0
    rows_only_in_target: int = 0
    sample_size: Optional[int] = None
    sample_match_rate: Optional[float] = None
    mismatched_examples: List[str] = field(default_factory=list)  # sample of hash values, for drill-down

    def status(self) -> str:
        if self.comparison_mode == "SKIPPED":
            return "NOT_COMPARED"
        if self.comparison_mode == "FULL":
            return "DATA_MATCH" if self.rows_only_in_source == 0 and self.rows_only_in_target == 0 else "DATA_MISMATCH"
        if self.comparison_mode == "SAMPLE":
            if self.sample_match_rate is None:
                return "NOT_COMPARED"
            return "DATA_MATCH" if self.sample_match_rate >= self._threshold else "DATA_MISMATCH"
        return "NOT_COMPARED"

    _threshold: float = 0.99  # set at construction time by compare_data()


def _pick_filter_column(spark, table_fqn: str, config: ReconciliationConfig) -> Optional[str]:
    cols = {f.lower() for f in spark.table(table_fqn).columns}
    for candidate in config.timestamp_filter_priority:
        if candidate in cols:
            return candidate
    return None


def _apply_filter(df: DataFrame, filter_col: Optional[str], window: Tuple[str, str]) -> DataFrame:
    if not filter_col:
        return df
    start, end = window
    # Case-insensitive column resolution
    actual_col = next((c for c in df.columns if c.lower() == filter_col), filter_col)
    return df.where((F.col(actual_col) >= F.lit(start)) & (F.col(actual_col) < F.lit(end)))


def _hash_df(df: DataFrame, columns: List[str]) -> DataFrame:
    """Row-level hash over the comparable columns, null-safe and order-independent per row."""
    actual_cols = []
    for c in columns:
        match = next((col for col in df.columns if col.lower() == c), None)
        if match:
            actual_cols.append(match)
    exprs = [F.coalesce(F.col(c).cast("string"), F.lit("\u0000NULL\u0000")) for c in sorted(actual_cols)]
    return df.select(F.sha2(F.concat_ws("||", *exprs), 256).alias("__row_hash__"))


def compare_data(
    spark,
    pair,
    schema_result: SchemaComparisonResult,
    config: ReconciliationConfig,
) -> DataComparisonResult:
    result = DataComparisonResult()
    result._threshold = config.sample_match_threshold

    comparable_cols = [c for c in schema_result.common_columns if c not in config.excluded_from_compare()]

    source_df_raw = spark.table(pair.source_fqn)
    target_df_raw = spark.table(pair.target_fqn)

    filter_col = _pick_filter_column(spark, pair.source_fqn, config)
    window = config.get_filter_window()

    if filter_col:
        result.filter_applied = True
        result.filter_column = filter_col
        result.filter_window = window
        source_df = _apply_filter(source_df_raw, filter_col, window)
        target_df = _apply_filter(target_df_raw, filter_col, window)
    else:
        source_df = source_df_raw
        target_df = target_df_raw

    if not comparable_cols:
        result.comparison_mode = "SKIPPED"
        return result

    source_count = source_df.count()
    target_count = target_df.count()
    result.source_row_count = source_count
    result.target_row_count = target_count

    if source_count == 0 and target_count == 0:
        result.comparison_mode = "FULL"
        return result

    src_hash = _hash_df(source_df, comparable_cols)
    tgt_hash = _hash_df(target_df, comparable_cols)

    do_full = (source_count == target_count) and (
        max(source_count, target_count) <= config.full_compare_row_limit
    )

    if do_full:
        result.comparison_mode = "FULL"
        only_source = src_hash.exceptAll(tgt_hash)
        only_target = tgt_hash.exceptAll(src_hash)
        result.rows_only_in_source = only_source.count()
        result.rows_only_in_target = only_target.count()
        if result.rows_only_in_source:
            result.mismatched_examples = [r["__row_hash__"] for r in only_source.limit(5).collect()]
    else:
        result.comparison_mode = "SAMPLE"
        smaller_count = min(source_count, target_count) or 1
        target_sample_n = min(
            config.large_table_sample_size if max(source_count, target_count) > config.full_compare_row_limit
            else config.sample_size,
            max(config.min_sample_size, int(smaller_count * config.sample_fraction_cap)),
        )
        target_sample_n = max(1, min(target_sample_n, smaller_count))
        result.sample_size = target_sample_n

        fraction = min(1.0, target_sample_n / smaller_count * 1.5)  # slight oversample, then cap with limit
        sampled = src_hash.sample(withReplacement=False, fraction=fraction, seed=42).limit(target_sample_n)
        actual_n = sampled.count()
        if actual_n == 0:
            result.sample_match_rate = None
        else:
            missing_in_target = sampled.join(tgt_hash, on="__row_hash__", how="left_anti")
            missing_n = missing_in_target.count()
            result.sample_match_rate = round(1 - (missing_n / actual_n), 4)
            result.rows_only_in_source = missing_n  # interpreted as "sampled rows not found on target"
            if missing_n:
                result.mismatched_examples = [r["__row_hash__"] for r in missing_in_target.limit(5).collect()]

    return result
