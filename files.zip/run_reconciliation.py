# Databricks notebook source
# MAGIC %md
# MAGIC # Guidewire ODS Reconciliation -- Read Replica vs CDA
# MAGIC Compares the current ODS views for PolicyCenter, BillingCenter and ClaimCenter
# MAGIC produced by the Read Replica pipeline against the CDA pipeline.
# MAGIC
# MAGIC Widgets below let this run interactively or as a scheduled job with
# MAGIC parameters supplied via `dbutils.widgets` / job parameters.

# COMMAND ----------
import sys
sys.path.append("/Workspace/Repos/<your-repo-path>/gw_ods_reconciliation")  # adjust for your workspace layout

from config import ReconciliationConfig
from reconcile import run_reconciliation

# COMMAND ----------
# MAGIC %md ### Parameters (job widgets, with sane interactive defaults)

# COMMAND ----------
dbutils.widgets.text("source_catalog", "core_tst")
dbutils.widgets.text("target_catalog", "core_tst_std001")
dbutils.widgets.text("lookback_days", "7")
dbutils.widgets.text("sample_size", "50000")
dbutils.widgets.dropdown("write_results", "true", ["true", "false"])

# COMMAND ----------
config = ReconciliationConfig(
    source_catalog=dbutils.widgets.get("source_catalog"),
    target_catalog=dbutils.widgets.get("target_catalog"),
    lookback_days=int(dbutils.widgets.get("lookback_days")),
    sample_size=int(dbutils.widgets.get("sample_size")),
    write_results_to_delta=(dbutils.widgets.get("write_results") == "true"),
)

# COMMAND ----------
summary_df = run_reconciliation(spark, config)
display(summary_df)

# COMMAND ----------
# MAGIC %md ### Quick health check
# MAGIC Fails the job (raises) if any table came back FAIL/ERROR, useful when
# MAGIC this notebook is wired into a Databricks Job with alerting.

# COMMAND ----------
from pyspark.sql import functions as F

failures = summary_df.where(F.col("overall_status").isin("FAIL", "ERROR"))
fail_count = failures.count()
print(f"{fail_count} table(s) FAILED or ERRORED out of {summary_df.count()} compared.")
if fail_count:
    display(failures.select(
        "domain", "source_table", "overall_status", "schema_status", "data_status", "comments"
    ))

# Uncomment to hard-fail the job on any FAIL/ERROR:
# if fail_count:
#     raise Exception(f"Reconciliation found {fail_count} failing table(s). See summary table for details.")
