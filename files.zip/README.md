# Guidewire ODS Reconciliation Framework

Compares Guidewire ODS views produced by the **Read Replica** pipeline against
the **CDA** pipeline for PolicyCenter, BillingCenter and ClaimCenter, to confirm
both pipelines produce functionally identical data despite different
implementations.

## How it works

```
discovery.py        -> finds RR tables per domain, derives CDA counterpart
                        (same name + "_cda"), flags missing tables either way
schema_compare.py    -> case-insensitive column diff: extra/missing columns,
                        datatype mismatches, nullability differences
data_compare.py       -> row counts, incremental filter on UPDATETIME /
                        CREATETIME, full hash-diff or representative sample
reconcile.py           -> orchestrates all of the above per table, is fault
                        tolerant (one bad table never kills the run), builds
                        the one-row-per-table summary and writes it to Delta
run_reconciliation.py  -> Databricks notebook entrypoint with job widgets
config.py               -> every catalog name, threshold and column list
```

## Table pairing

`core_tst.ods_views.vw_policycenter_current_pc_accountcontact`
maps to
`core_tst_std001.ods_views.vw_policycenter_current_pc_accountcontact_cda`

Tables are **discovered** from the catalog at run time (`SHOW TABLES`), not
hard-coded, so the framework scales to hundreds of tables across all three
domains without code changes -- add a table in Databricks and it's picked up
on the next run.

## Column handling

| Category | Examples | Treatment |
|---|---|---|
| Audit/pipeline columns | `AZURE_LOAD_DATE`, `DWH_CURRENT_FLAG`, `DWH_FROM_DATE`, `DWH_UNTIL_DATE`, `BEANVERSION`, `ARCHIVEPARTITION` | Excluded from data comparison; reported as "ignored by design" |
| CDA-only CDC column | `gwcbi___operation` | Fully ignored, not even reported as drift |
| Everything else | business columns | Compared for schema (type/nullability) and data (hash-diff) |

Column matching is **case-insensitive** since Read Replica columns are
lower_snake_case and CDA columns are UPPER_SNAKE_CASE in this environment.

## Schema validation

CDA is allowed to drift (schema evolution); Read Replica is the manually
controlled baseline.

- Column only in Read Replica → `SCHEMA_MISMATCH` (unexpected, RR is baseline)
- Column only in CDA → `SCHEMA_DRIFT` (expected/allowed, still reported)
- Datatype differs on a common column → mismatch, listed with both types
- Nullability differs on a common column → listed, non-blocking

Comparison of **data** always proceeds on the common columns regardless of
drift -- a schema mismatch never skips the data check.

## Data comparison strategy

1. Pick a filter column: `UPDATETIME` if present, else `CREATETIME`, else none.
2. Apply the configured date window (`lookback_days`, or explicit
   `filter_start_date` / `filter_end_date`) to both sides if a filter column
   exists; otherwise compare the full table.
3. Get row counts on both sides.
   - **Counts match** (and table isn't huge) → full comparison: SHA-256 hash
     each row over the comparable columns, `exceptAll` both directions to
     find rows unique to either side.
   - **Counts differ** (expected in this test environment since RR refreshes
     daily and CDA is loaded on demand) → representative random sample from
     the smaller side, checked for presence in the other side via anti-join;
     reports a match rate instead of silently skipping the table.
   - Very large tables (> `full_compare_row_limit`) fall back to a larger
     sample even when counts match, to protect cluster resources.

## Output

One row per table is written to
`core_tst_std001.recon_reporting.gw_ods_reconciliation_summary` (Delta,
append mode, keyed by `run_id`/`run_timestamp` so history is retained), with:

`domain, source_table, target_table, table_status, schema_status, data_status,
overall_status, source_row_count, target_row_count, comparison_mode,
filter_applied, filter_column, rows_only_in_source, rows_only_in_target,
sample_size, sample_match_rate, columns_only_in_source, columns_only_in_target,
datatype_mismatches, nullability_mismatches, duration_seconds, comments`

`overall_status` is one of `PASS`, `WARN` (e.g. CDA-side schema drift only),
`FAIL` (missing table, schema mismatch, or data mismatch), `ERROR` (the
comparison itself failed, e.g. permission/connectivity issue).

## Fault tolerance & operations

- Each table is wrapped in its own try/except with configurable retry
  (`max_table_retries`); a failure never stops the run for other tables.
- `RunMetrics` accumulates per-status counts and per-table durations, logged
  as a structured summary at the end of the run.
- `fail_run_if_error_rate_above` can hard-fail the Databricks job if too many
  tables errored, so pipeline breakage is caught by job alerting.
- `run_reconciliation.py` includes a quick health-check cell that surfaces
  all FAIL/ERROR rows and can be uncommented to fail the job.

## Running it

```python
from config import ReconciliationConfig
from reconcile import run_reconciliation

config = ReconciliationConfig(
    lookback_days=14,
    sample_size=100_000,
)
summary_df = run_reconciliation(spark, config)
display(summary_df)
```

Or schedule `run_reconciliation.py` as a Databricks Job/Workflow with the
widgets (`source_catalog`, `target_catalog`, `lookback_days`, `sample_size`,
`write_results`) supplied as job parameters.

## Extending

- New domain (e.g. a 4th Guidewire product): add one entry to
  `ReconciliationConfig.domains`.
- New audit column: add to `audit_columns` in config -- no code changes.
- Different sampling strategy or match threshold: tune
  `sample_fraction_cap`, `min_sample_size`, `sample_match_threshold`,
  `full_compare_row_limit` in `config.py`.
