"""
schema_compare.py
------------------
Compares the schema (columns, data types, nullability) of a Read Replica
table against its CDA counterpart. CDA is allowed to drift (extra/missing
columns, wider types from schema evolution); Read Replica is the manually
controlled baseline. Mismatches are captured but never block the data
comparison of the remaining common columns.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from config import ReconciliationConfig


@dataclass
class ColumnInfo:
    name: str            # lower-cased, normalized
    data_type: str
    nullable: bool


@dataclass
class SchemaComparisonResult:
    columns_only_in_source: List[str] = field(default_factory=list)
    columns_only_in_target: List[str] = field(default_factory=list)
    datatype_mismatches: List[Tuple[str, str, str]] = field(default_factory=list)   # (col, src_type, tgt_type)
    nullability_mismatches: List[Tuple[str, bool, bool]] = field(default_factory=list)
    common_columns: List[str] = field(default_factory=list)
    ignored_columns: List[str] = field(default_factory=list)  # audit + cda-only, excluded by design
    has_drift: bool = False

    def status(self) -> str:
        if self.columns_only_in_source or self.datatype_mismatches:
            # Extra/missing columns on the *source* side or real type
            # conflicts are the meaningful "schema mismatch" signal.
            return "SCHEMA_MISMATCH"
        if self.columns_only_in_target:
            # CDA-side drift is allowed/expected but still worth flagging.
            return "SCHEMA_DRIFT"
        return "SCHEMA_MATCH"


def _get_columns(spark, table_fqn: str) -> Dict[str, ColumnInfo]:
    """
    Build a case-insensitive column map for a table, including nullability
    where the catalog exposes it (Unity Catalog information_schema).
    Falls back to the Spark DataFrame schema (nullable defaults to True)
    if information_schema isn't accessible.
    """
    df = spark.table(table_fqn)
    cols = {
        f.name.lower(): ColumnInfo(name=f.name.lower(), data_type=f.dataType.simpleString(), nullable=f.nullable)
        for f in df.schema.fields
    }

    try:
        catalog, schema, table = table_fqn.split(".")
        info_rows = spark.sql(f"""
            SELECT lower(column_name) AS column_name, is_nullable
            FROM {catalog}.information_schema.columns
            WHERE lower(table_schema) = lower('{schema}') AND lower(table_name) = lower('{table}')
        """).collect()
        for r in info_rows:
            if r["column_name"] in cols:
                cols[r["column_name"]].nullable = (str(r["is_nullable"]).upper() == "YES")
    except Exception:
        pass  # non-fatal: nullability just falls back to Spark schema defaults

    return cols


def _normalize_type(dtype: str) -> str:
    """Loosen cosmetic type differences that aren't meaningful mismatches."""
    dtype = dtype.lower().strip()
    if dtype.startswith("varchar") or dtype.startswith("char"):
        return "string"
    return dtype


def compare_schema(spark, pair, config: ReconciliationConfig) -> SchemaComparisonResult:
    result = SchemaComparisonResult()
    excluded = config.excluded_from_compare()

    source_cols = _get_columns(spark, pair.source_fqn)
    target_cols = _get_columns(spark, pair.target_fqn)

    source_names = set(source_cols) - excluded
    target_names = set(target_cols) - excluded

    result.columns_only_in_source = sorted(source_names - target_names)
    result.columns_only_in_target = sorted(target_names - source_names)
    result.ignored_columns = sorted(excluded & (set(source_cols) | set(target_cols)))
    result.common_columns = sorted(source_names & target_names)

    for col in result.common_columns:
        s_type = _normalize_type(source_cols[col].data_type)
        t_type = _normalize_type(target_cols[col].data_type)
        if s_type != t_type:
            result.datatype_mismatches.append((col, s_type, t_type))

        s_null, t_null = source_cols[col].nullable, target_cols[col].nullable
        # Only flag when source is NOT NULL but target allows nulls (or vice
        # versa) -- meaningful contract difference, not Spark's default
        # "everything nullable" noise.
        if s_null != t_null:
            result.nullability_mismatches.append((col, s_null, t_null))

    result.has_drift = bool(
        result.columns_only_in_source or result.columns_only_in_target or result.datatype_mismatches
    )
    return result
