"""
config.py
---------
Central, editable configuration for the Guidewire ODS Reconciliation
Framework (Read Replica vs CDA).

Nothing in the rest of the codebase should hard-code catalog names,
column lists, or thresholds -- everything comes from here so the same
code scales from 3 tables to hundreds across PolicyCenter, BillingCenter
and ClaimCenter without modification.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional


@dataclass
class ReconciliationConfig:
    # ------------------------------------------------------------------
    # Catalog / schema layout
    # ------------------------------------------------------------------
    source_catalog: str = "core_tst"            # Read Replica (baseline)
    target_catalog: str = "core_tst_std001"      # CDA
    schema_name: str = "ods_views"
    target_table_suffix: str = "_cda"

    # Guidewire domain -> current-view name prefix (used only for
    # discovery filtering; the actual table list is enumerated from the
    # catalog at run time so new tables are picked up automatically).
    domains: Dict[str, str] = field(default_factory=lambda: {
        "policycenter": "vw_policycenter_current_p",
        "billingcenter": "vw_billingcenter_current_b",
        "claimcenter": "vw_claimcenter_current_c",
    })

    # ------------------------------------------------------------------
    # Column handling
    # ------------------------------------------------------------------
    # Pipeline/audit columns that are EXPECTED to differ between the two
    # pipelines and must be excluded from data comparison. Still reported
    # on, but never counted as a mismatch. Case-insensitive.
    audit_columns: List[str] = field(default_factory=lambda: [
        "azure_load_date",
        "dwh_current_flag",
        "dwh_from_date",
        "dwh_until_date",
        "beanversion",
        "archivepartition",
    ])

    # Columns that exist only in CDA by design (CDC metadata) and must be
    # ignored entirely -- not even reported as schema drift.
    cda_only_columns: List[str] = field(default_factory=lambda: [
        "gwcbi___operation",
    ])

    # Timestamp columns to search for (priority order) to drive the
    # incremental filter. First one found on the table wins.
    timestamp_filter_priority: List[str] = field(default_factory=lambda: [
        "updatetime", "createtime",
    ])

    # ------------------------------------------------------------------
    # Incremental filter window
    # ------------------------------------------------------------------
    lookback_days: int = 7
    filter_start_date: Optional[str] = None   # "YYYY-MM-DD", overrides lookback_days
    filter_end_date: Optional[str] = None     # "YYYY-MM-DD"

    # ------------------------------------------------------------------
    # Row-count-mismatch sampling behaviour (test env: RR refreshed daily,
    # CDA loaded on demand -> counts routinely diverge)
    # ------------------------------------------------------------------
    sample_size: int = 50_000
    sample_fraction_cap: float = 0.20   # never sample >20% of the smaller side
    min_sample_size: int = 1_000
    sample_match_threshold: float = 0.99  # >=99% of sampled rows must match

    # Guardrail: even when row counts match exactly, fall back to a
    # (larger) sample instead of a full shuffle-heavy compare once a
    # table exceeds this many rows, to protect cluster resources.
    full_compare_row_limit: int = 20_000_000
    large_table_sample_size: int = 500_000

    # ------------------------------------------------------------------
    # Output / persistence
    # ------------------------------------------------------------------
    output_catalog: str = "core_tst_std001"
    output_schema: str = "recon_reporting"
    output_table: str = "gw_ods_reconciliation_summary"
    write_results_to_delta: bool = True
    results_mode: str = "append"   # "append" keeps run history; add run_id/run_ts columns

    # ------------------------------------------------------------------
    # Resilience / execution
    # ------------------------------------------------------------------
    continue_on_error: bool = True
    max_table_retries: int = 1
    fail_run_if_error_rate_above: Optional[float] = None  # e.g. 0.5 to hard-fail the job

    def get_filter_window(self):
        """Return (start_date, end_date) strings for the incremental filter."""
        if self.filter_start_date and self.filter_end_date:
            return self.filter_start_date, self.filter_end_date
        end = datetime.utcnow().date()
        start = end - timedelta(days=self.lookback_days)
        return start.isoformat(), (end + timedelta(days=1)).isoformat()

    def output_table_fqn(self) -> str:
        return f"{self.output_catalog}.{self.output_schema}.{self.output_table}"

    def source_schema_fqn(self) -> str:
        return f"{self.source_catalog}.{self.schema_name}"

    def target_schema_fqn(self) -> str:
        return f"{self.target_catalog}.{self.schema_name}"

    def excluded_from_compare(self) -> set:
        """All columns ignored for DATA comparison (audit + cda-only)."""
        return {c.lower() for c in self.audit_columns} | {c.lower() for c in self.cda_only_columns}
