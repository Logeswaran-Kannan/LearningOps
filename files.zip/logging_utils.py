"""
logging_utils.py
-----------------
Structured logging + lightweight run metrics for the reconciliation job.
Uses standard `logging` so it plays nicely with Databricks driver logs,
plus an in-memory metrics collector that gets flushed to the summary
output at the end of the run.
"""
import json
import logging
import sys
import time
import uuid
from collections import Counter
from contextlib import contextmanager
from datetime import datetime


def get_logger(name: str = "gw_ods_reconciliation") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # avoid duplicate handlers on notebook re-run
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(handler)
    logger.propagate = False
    return logger


class RunMetrics:
    """Aggregates counters and timings across the whole reconciliation run."""

    def __init__(self):
        self.run_id = str(uuid.uuid4())
        self.started_at = datetime.utcnow()
        self.finished_at = None
        self.status_counts = Counter()
        self.table_durations = {}
        self.errors = {}

    def record_status(self, table_name: str, status: str):
        self.status_counts[status] += 1

    def record_duration(self, table_name: str, seconds: float):
        self.table_durations[table_name] = seconds

    def record_error(self, table_name: str, err: Exception):
        self.errors[table_name] = repr(err)

    def finalize(self):
        self.finished_at = datetime.utcnow()

    def error_rate(self) -> float:
        total = sum(self.status_counts.values())
        if total == 0:
            return 0.0
        return self.status_counts.get("ERROR", 0) / total

    def summary_dict(self):
        return {
            "run_id": self.run_id,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "total_tables": sum(self.status_counts.values()),
            "status_breakdown": dict(self.status_counts),
            "error_count": len(self.errors),
            "errors": self.errors,
        }

    def print_summary(self, logger: logging.Logger):
        logger.info("=" * 70)
        logger.info("RECONCILIATION RUN SUMMARY")
        logger.info(json.dumps(self.summary_dict(), indent=2, default=str))
        logger.info("=" * 70)


@contextmanager
def timed(metrics: RunMetrics, table_name: str):
    start = time.time()
    try:
        yield
    finally:
        metrics.record_duration(table_name, round(time.time() - start, 2))
