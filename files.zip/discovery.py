"""
discovery.py
------------
Discovers the current ODS views in the Read Replica catalog for each
Guidewire domain, derives the expected CDA counterpart name (same name
+ `_cda` suffix), and confirms existence on both sides. Read Replica is
treated as the source of truth: every RR table is expected to exist in
CDA. Tables present only in CDA are also reported for completeness.

Table naming follows the pattern observed in the environment, e.g.:
  RR:  core_tst.ods_views.vw_policycenter_current_pc_accountcontact
  CDA: core_tst_std001.ods_views.vw_policycenter_current_pc_accountcontact_cda
"""
from dataclasses import dataclass
from typing import List

from config import ReconciliationConfig


@dataclass
class TablePair:
    domain: str
    source_table: str          # bare table name in source catalog
    target_table: str          # expected bare table name in target catalog
    source_fqn: str
    target_fqn: str
    exists_in_source: bool
    exists_in_target: bool


def _list_tables(spark, schema_fqn: str) -> List[str]:
    """Return lower-cased bare table names in a catalog.schema."""
    try:
        rows = spark.sql(f"SHOW TABLES IN {schema_fqn}").collect()
        # SHOW TABLES returns columns: database, tableName, isTemporary
        return [r["tableName"].lower() for r in rows]
    except Exception:
        # Fallback to catalog API
        return [t.name.lower() for t in spark.catalog.listTables(schema_fqn)]


def discover_table_pairs(spark, config: ReconciliationConfig) -> List[TablePair]:
    """
    Enumerate current ODS views for every configured domain and build the
    RR <-> CDA table pairing. Auto-scales to any number of tables per
    domain -- no hard-coded table list required.
    """
    source_schema = config.source_schema_fqn()
    target_schema = config.target_schema_fqn()

    source_tables = set(_list_tables(spark, source_schema))
    target_tables = set(_list_tables(spark, target_schema))

    pairs: List[TablePair] = []

    for domain, prefix in config.domains.items():
        prefix_lc = prefix.lower()
        domain_source_tables = sorted(t for t in source_tables if t.startswith(prefix_lc))

        for src_table in domain_source_tables:
            tgt_table = f"{src_table}{config.target_table_suffix}"
            pairs.append(TablePair(
                domain=domain,
                source_table=src_table,
                target_table=tgt_table,
                source_fqn=f"{source_schema}.{src_table}",
                target_fqn=f"{target_schema}.{tgt_table}",
                exists_in_source=True,
                exists_in_target=tgt_table in target_tables,
            ))

    return pairs


def find_cda_only_tables(spark, config: ReconciliationConfig) -> List[str]:
    """
    Tables that exist in CDA (matching a configured domain + _cda suffix)
    but have no corresponding Read Replica source table. Informational
    only -- RR is the baseline, so this does not fail the run.
    """
    source_schema = config.source_schema_fqn()
    target_schema = config.target_schema_fqn()
    source_tables = set(_list_tables(spark, source_schema))
    target_tables = set(_list_tables(spark, target_schema))

    orphans = []
    for domain, prefix in config.domains.items():
        prefix_lc = prefix.lower()
        for t in target_tables:
            if t.startswith(prefix_lc) and t.endswith(config.target_table_suffix):
                implied_source = t[: -len(config.target_table_suffix)]
                if implied_source not in source_tables:
                    orphans.append(t)
    return sorted(orphans)
